package infy.product.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import infy.product.model.Product;

public interface ProductRepository extends MongoRepository<Product, String> {

}
