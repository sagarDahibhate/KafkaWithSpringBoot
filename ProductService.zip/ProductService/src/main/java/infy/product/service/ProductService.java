package infy.product.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import infy.product.exception.OutOfStockException;
import infy.product.exception.ProductNotFoundException;
import infy.product.model.Product;
import infy.product.repo.ProductRepository;

@Service
public class ProductService {
	
	private static final Logger log =
            LoggerFactory.getLogger(ProductService.class);

	@Autowired
    private ProductRepository repository;

    public List<Product> getAllProducts() {
    	 log.info("Calling repository to fetch all products");
        return repository.findAll();
    }

    @Cacheable(value = "products", key = "#id")
    public Product getProductById(String id) {
    	 log.info("Fetching product from DB for id: {}", id);

         return repository.findById(id)
                 .orElseThrow(() -> {
                     log.error("Product not found for id: {}", id);
                     return new ProductNotFoundException("Product not found: " + id);
                 });
    }
 
    public Product addProduct(Product product) {
    	log.info("Saving product to database");
        return repository.save(product);
    }

   @CacheEvict(value = "products", key = "#id")
    public Product updateProduct(String id, Product updatedProduct) {
	   
	   log.info("Fetching existing product for update, id: {}", id);
	   
        Product existing = getProductById(id);
        existing.setName(updatedProduct.getName());
        existing.setPrice(updatedProduct.getPrice());
        existing.setQuantity(updatedProduct.getQuantity());
        existing.setDescription(updatedProduct.getDescription());
        
        log.info("Updating product in DB, id: {}", id);
        
        return repository.save(existing);
    }
   
   @Transactional
   public void reduceStock(String id, int quantity) {
	   
	   log.info("Initiating stock reduction for id: {}", id);


	   Product product = repository.findById(id)
               .orElseThrow(() -> {
                   log.error("Product not found during stock reduction, id: {}", id);
                   return new ProductNotFoundException("Product not found");
               });

       
       if (product.getQuantity() < quantity) {
           log.error("Insufficient stock for id: {}. Available: {}, Requested: {}",
                   id, product.getQuantity(), quantity);
           throw new OutOfStockException("Insufficient stock please wait");
       }

       product.setQuantity(product.getQuantity() - quantity);

       repository.save(product);

       log.info("Stock reduced successfully for id: {}. Remaining quantity: {}",
               id, product.getQuantity());
   }
}
