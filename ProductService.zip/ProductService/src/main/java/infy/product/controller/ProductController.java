package infy.product.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import infy.product.model.Product;
import infy.product.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

	private static final Logger log =
            LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	private ProductService service;
	
	

	@PostMapping("/create")
	public ResponseEntity<Product> create(@RequestBody Product product) {
		
		log.info("Received request to create product: {}", product.getName());

		if (product == null) {
			log.warn("Product request body is null");
            return ResponseEntity.badRequest().build();
        }

        Product saved = service.addProduct(product);
        
        log.info("Product created successfully with id: {}", saved.getId());

        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
	}
	
	
	
	@GetMapping("/getAllProducts")
	public ResponseEntity<List<Product>> getAll() {
		
		log.info("Fetching all products");
		
		List<Product> products = service.getAllProducts();

        if (products.isEmpty()) {
        	 log.info("No products found");
            return ResponseEntity.noContent().build();
        }
        
        log.info("Total products fetched: {}", products.size());
        
        return ResponseEntity.ok(products);
	}
	
	

	@GetMapping("/getById/{id}")
	public ResponseEntity<Product> getById(@PathVariable String id) {
		
		log.info("Fetching product by id: {}", id);

        Product product = service.getProductById(id);

        log.info("Product fetched successfully for id: {}", id);
        
     return new ResponseEntity<Product>(product,HttpStatus.OK);  
	}
	
	
	

	@PutMapping("/update/{id}")
	public ResponseEntity<Product> update(@PathVariable String id, @RequestBody Product product) {
       
		log.info("Updating product with id: {}", id);
 
		if (!StringUtils.hasText(id)) {
			 log.warn("Invalid product id provided");
	            return ResponseEntity.badRequest().build();
	        }

	        Product updated = service.updateProduct(id, product);
	       
	        log.info("Product updated successfully for id: {}", id);

	        return ResponseEntity.ok(updated);
	}
	
	
	
	@PutMapping("/reduceStock/{id}")
	public ResponseEntity<String> reduceStock(
	        @PathVariable String id,
	        @RequestParam int quantity) {

		log.info("Reducing stock for product id: {} by quantity: {}", id, quantity);

        service.reduceStock(id, quantity);

        log.info("Stock reduced successfully for id: {}", id);
        
	    return ResponseEntity.ok("Stock updated");
	}
}
