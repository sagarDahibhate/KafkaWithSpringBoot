package infy.product.exception;

import org.springframework.http.HttpStatus;

public class ProductNotFoundException extends RuntimeException {

	private HttpStatus status;
	private String message;

	public ProductNotFoundException(String message) {
		this.message = message;
		this.status = HttpStatus.NOT_FOUND;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

}