package infy.product.exception;

public class OutOfStockException extends RuntimeException {

	private String message;

	public OutOfStockException(String message) {
		this.message = message;
	}
	 
	public String getMessage() {
		return message;
	}

}