package infy.product.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	 private static final Logger log =
	            LoggerFactory.getLogger(GlobalExceptionHandler.class);
	 
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> handleException(RuntimeException ex) {
		
		log.error("Unhandled exception occurred", ex);
		
		return ResponseEntity.badRequest().body(ex.getMessage());
	}

	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleException(ProductNotFoundException ex) {
		
		log.warn("Business exception occurred: {}", ex.getMessage());
		
		ErrorResponse response = new ErrorResponse(ex.getMessage(), HttpStatus.NOT_FOUND);

		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

	}
	
	@ExceptionHandler(OutOfStockException.class)
	public ResponseEntity<ErrorResponse> handleException(OutOfStockException ex) {
		
		log.warn("Business exception occurred: {}", ex.getMessage());
		
		ErrorResponse response = new ErrorResponse(ex.getMessage(), HttpStatus.NOT_FOUND);

		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

	}

}