package infy.product.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import infy.product.model.Product;
import infy.product.service.ProductService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

@WebMvcTest(ProductController.class)
class ProductControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProductService service;

    @Test
    void testGetById() throws Exception {

        Product product = new Product();
        product.setId("101");
        product.setName("Mobile");

        when(service.getProductById("101"))
                .thenReturn(product);

        mockMvc.perform(get("/products/getById/101"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Mobile"));
    }

    @Test
    void testGetAll() throws Exception {

        when(service.getAllProducts())
                .thenReturn(Arrays.asList(new Product()));

        mockMvc.perform(get("/products/getAllProducts"))
                .andExpect(status().isOk());
    }

    @Test
    void testReduceStock() throws Exception {

        doNothing().when(service).reduceStock("101", 5);

        mockMvc.perform(put("/products/reduceStock/101")
                .param("quantity", "5"))
                .andExpect(status().isOk());
    }
}