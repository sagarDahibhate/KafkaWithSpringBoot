package infy.product.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import infy.product.exception.OutOfStockException;
import infy.product.exception.ProductNotFoundException;
import infy.product.model.Product;
import infy.product.repo.ProductRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceTest {

    @Mock
    private ProductRepository repository;

    @InjectMocks
    private ProductService service;

    private Product product;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
        product = new Product();
        product.setId("101");
        product.setName("Mobile");
        product.setQuantity(10);
        product.setPrice(2000.0);
    }

    @Test
    void testGetProductById_Success() {
        when(repository.findById("101"))
                .thenReturn(Optional.of(product));

        Product result = service.getProductById("101");

        assertNotNull(result);
        assertEquals("Mobile", result.getName());
    }

    @Test
    void testGetProductById_NotFound() {
        when(repository.findById("999"))
                .thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class,
                () -> service.getProductById("999"));
    }

    @Test
    void testReduceStock_Success() {
        when(repository.findById("101"))
                .thenReturn(Optional.of(product));

        service.reduceStock("101", 5);

        assertEquals(5, product.getQuantity());
        verify(repository, times(1)).save(product);
    }

    @Test
    void testReduceStock_Insufficient() {
        when(repository.findById("101"))
                .thenReturn(Optional.of(product));

        assertThrows(OutOfStockException.class,
                () -> service.reduceStock("101", 20));
    }
}