1. Architecture Overview

This project is a microservices-based Order Management System built using Spring Boot and MongoDB.  
It consists of two independent services:

-  Product Service
-  Order Service


1) Product Service
=================
Responsible for inventory management  Uses MongoDB for data persistence
Provides CRUD APIs:
--------------------
GET /products/update
GET /products/update/{id}
POST /products/create
PUT /products/update/{id}

Implements in-memory caching for GET by ID ,Cache is invalidated on product update


2) Order Service
===============

Responsible for order processing Communicates with Product Service using OpenFeign ,
Validates product availability before placing order

Flow->
------- 
1. User calls POST /orders/placeOrder
2. Order Service calls Product Service via Feign Client
3. Product Service:
   - Checks product availability
   - Validates stock
   - Reduces stock
4. Order Service:
   - Saves order in MongoDB
5. Response returned with HTTP 201

Implements logging using SLF4J
Implements global exception handling

Exposes API:
-------------
POST /orders/placeOrder

Communication Flow
-------------------
Client → Order Service → Product Service → MongoDB

3) Technologies Used
=====================

Spring Boot
Spring Data MongoDB
Spring Cloud OpenFeign
MongoDB
SLF4J Logging
Swagger (OpenAPI)
Maven

4). How to Build and Run
=========================
Prerequisites
--------------
Java 17
Maven
MongoDB running locally

Step 1 – Start MongoDB

Ensure MongoDB is running on:  mongodb://localhost:27017

Step 2 – Run Product Service

cd product-service

mvn clean install

mvn spring-boot:run

Runs on:

http://localhost:8081


Step 3 – Run Order Service
cd order-service
mvn clean install
mvn spring-boot:run

Runs on:

http://localhost:8082


5). API Documentation
======================

Swagger UI:
------------
Product Service:

http://localhost:8081/swagger-ui.html

Order Service:

http://localhost:8082/swagger-ui.html
 