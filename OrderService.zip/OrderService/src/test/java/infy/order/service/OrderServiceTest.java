package infy.order.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import infy.order.dto.OrderRequest;
import infy.order.dto.OrderResponse;
import infy.order.feign.ProductClient;
import infy.order.model.Order;
import infy.order.repo.OrderRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

class OrderServiceTest {

    @Mock
    private ProductClient productClient;

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    private OrderRequest request;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        request = new OrderRequest();
        request.setProductId("101");
        request.setQuantity(5);
    }

    // ✅ Successful Order
    @Test
    void testPlaceOrder_Success() {

        doNothing().when(productClient)
                .reduceStock("101", 5);

        when(orderRepository.save(any(Order.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        OrderResponse response =
                orderService.placeOrder(request);

        assertNotNull(response);
        assertEquals("Order placed successfully",
                response.getMessage());

        verify(productClient, times(1))
                .reduceStock("101", 5);

        verify(orderRepository, times(1))
                .save(any(Order.class));
    }

    // ❌ Product Service throws exception
    @Test
    void testPlaceOrder_ProductServiceFailure() {

        doThrow(new RuntimeException("Insufficient stock"))
                .when(productClient)
                .reduceStock("101", 5);

        assertThrows(RuntimeException.class,
                () -> orderService.placeOrder(request));

        verify(orderRepository, never())
                .save(any(Order.class));
    }
}