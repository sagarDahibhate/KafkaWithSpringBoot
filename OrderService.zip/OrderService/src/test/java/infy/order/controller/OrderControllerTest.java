package infy.order.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import infy.order.dto.OrderRequest;
import infy.order.dto.OrderResponse;
import infy.order.service.OrderService;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(OrderController.class)
class OrderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OrderService orderService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testPlaceOrder() throws Exception {

        OrderRequest request = new OrderRequest();
        request.setProductId("101");
        request.setQuantity(5);

        OrderResponse response =
                new OrderResponse("Order placed successfully",
                        "101", 5);

        when(orderService.placeOrder(any(OrderRequest.class)))
                .thenReturn(response);

        mockMvc.perform(post("/orders/placeOrder")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message")
                        .value("Order placed successfully"));
    }
}