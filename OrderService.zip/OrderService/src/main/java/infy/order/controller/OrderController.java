package infy.order.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import infy.order.dto.OrderRequest;
import infy.order.dto.OrderResponse;
import infy.order.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	private static final Logger log =
            LoggerFactory.getLogger(OrderController.class);


    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/placeOrder")
    public ResponseEntity<OrderResponse> placeOrder(
            @RequestBody OrderRequest request) {
    	
    	log.info("Received order request for productId: {} quantity: {}",
                request.getProductId(), request.getQuantity());

        OrderResponse response =
                orderService.placeOrder(request);

        log.info("Order placed successfully for productId: {}",
                request.getProductId());


        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
}