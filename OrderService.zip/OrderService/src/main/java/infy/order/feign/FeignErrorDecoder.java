package infy.order.feign;

import feign.Response;
import feign.codec.ErrorDecoder;
import infy.order.exception.OutOfStockException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

@Configuration
public class FeignErrorDecoder implements ErrorDecoder {
	
	private static final Logger log =
            LoggerFactory.getLogger(FeignErrorDecoder.class);

    @Override
    public Exception decode(String methodKey, Response response) {

        try {
            String message = new BufferedReader(
                    new InputStreamReader(response.body().asInputStream()))
                    .lines()
                    .collect(Collectors.joining("\n"));

            log.error("Feign call failed. Method: {}, Status: {}, Response: {}",
                    methodKey,
                    response.status(),
                    message);
            
            return new OutOfStockException(message,HttpStatus.CONFLICT);

        } catch (Exception e) {
            return new RuntimeException("Service error");
        }
    }
}