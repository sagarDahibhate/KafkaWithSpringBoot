package infy.order.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(name = "product-service", url = "${product-service.url}")
public interface ProductClient {
     
    @PutMapping("/products/reduceStock/{id}")
    void reduceStock(@PathVariable String id,
                     @RequestParam int quantity);
}