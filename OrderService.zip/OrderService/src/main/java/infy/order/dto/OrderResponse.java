package infy.order.dto;

public class OrderResponse {

    private String message;
    private String productId;
    private Integer orderedQuantity;

    public OrderResponse(String message, String productId, Integer orderedQuantity) {
        this.message = message;
        this.productId = productId;
        this.orderedQuantity = orderedQuantity;
    }

    public String getMessage() {
        return message;
    }

    public String getProductId() {
        return productId;
    }

    public Integer getOrderedQuantity() {
        return orderedQuantity;
    }
}