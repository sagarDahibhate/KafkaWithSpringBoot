package infy.order.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import infy.order.dto.OrderRequest;
import infy.order.dto.OrderResponse;
import infy.order.feign.ProductClient;
import infy.order.model.Order;
import infy.order.repo.OrderRepository;

@Service
public class OrderService {
	
	private static final Logger log =
	        LoggerFactory.getLogger(OrderService.class);

    @Autowired
    private ProductClient productClient;
    
    @Autowired
    private OrderRepository orderRepository;
    
 
    @Transactional
    public OrderResponse placeOrder(OrderRequest request) {


        log.info("Starting order placement process for productId: {}",
                request.getProductId());
 
        productClient.reduceStock(
                request.getProductId(),
                request.getQuantity());
        
        log.info("Stock verified and reduced successfully");

        Order order = new Order();
        order.setProductId(request.getProductId());
        order.setQuantity(request.getQuantity());

        orderRepository.save(order);

        log.info("Order saved successfully in database");

        return new OrderResponse(
                "Order placed successfully",
                request.getProductId(),
                request.getQuantity()
        );
    }
}
